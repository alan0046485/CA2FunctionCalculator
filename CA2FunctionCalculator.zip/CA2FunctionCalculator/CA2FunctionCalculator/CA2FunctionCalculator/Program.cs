﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FunctionCalculator;

namespace CA2FunctionCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            string choice;
            double i, j;
            bool keepGoing = true;

            while (keepGoing)
            {


                Console.WriteLine();
                Console.WriteLine("Welcome to your Calculator\nPlease enter your choice. Please press:\n");
                Console.WriteLine("'+' for Addition\n'-' for Subtraction\n'*' for Multiplication\n'/'for Division\n'S' for Square\n'C' for Cube");
                Console.WriteLine("'SR' for Square Root\n'O' for Circle Area\n'T' for Triangle Area\n'R' for Remainder\n'Q' to quit the program");
                choice = Console.ReadLine();

                /* Defensively minded switch statement with default to catch any incorrect user input at the calculator level
                and try catch to capture any incorrect user input when inputting numbers */

                try
                {

                    switch (choice)
                    {
                        case "+":
                            Console.Clear();
                            Calculator sum = new Calculator();
                            Console.WriteLine("Please enter your first number");
                            i = double.Parse(Console.ReadLine());
                            Console.WriteLine("Please enter your second number");
                            j = double.Parse(Console.ReadLine());
                            Console.WriteLine($"Answer: {sum.Add(i, j)}");

                            break;

                        case "-":
                            Console.Clear();
                            Calculator minus = new Calculator();
                            Console.WriteLine("Please enter your first number");
                            i = double.Parse(Console.ReadLine());
                            Console.WriteLine("Please enter your second number");
                            j = double.Parse(Console.ReadLine());
                            Console.WriteLine($"Answer: {minus.Subtract(i, j)}");

                            break;

                        case "*":
                            Console.Clear();
                            Calculator multiply = new Calculator();
                            Console.WriteLine("Please enter your first number");
                            i = double.Parse(Console.ReadLine());
                            Console.WriteLine("Please enter your second number");
                            j = double.Parse(Console.ReadLine());
                            Console.WriteLine($"Answer: {multiply.Multiplication(i, j)}");

                            break;

                        case "/":
                            Console.Clear();
                            Calculator div = new Calculator();
                            Console.WriteLine("Please enter your first number");
                            i = double.Parse(Console.ReadLine());
                            Console.WriteLine("Please enter your second number");
                            j = double.Parse(Console.ReadLine());

                            // if statement needed to capture dividing by 0

                            if (j == 0)
                            {
                                Console.WriteLine("You cannot divide by 0 please select again");
                            }

                            else
                            {
                                Console.WriteLine($"Answer: {div.Division(i, j)}");
                            }

                            break;

                        case "S":
                            Console.Clear();
                            Calculator sqr = new Calculator();
                            Console.WriteLine("Please enter the number you would like to square");
                            i = double.Parse(Console.ReadLine());

                            Console.WriteLine($"Answer: {sqr.Square(i)}");

                            break;

                        case "C":
                            Console.Clear();
                            Calculator cube = new Calculator();
                            Console.WriteLine("Please enter the number you would like to cube");
                            i = double.Parse(Console.ReadLine());

                            Console.WriteLine($"Answer: {cube.Cube(i)}");

                            break;

                        case "SR":
                            Console.Clear();
                            Calculator sr = new Calculator();
                            Console.WriteLine("Please enter the number you would like to get the square root of");
                            i = double.Parse(Console.ReadLine());

                            Console.WriteLine($"Answer: {sr.SquareRoot(i)}");

                            break;

                        case "O":
                            Console.Clear();
                            Calculator circle = new Calculator();
                            Console.WriteLine("Please enter the radius of your circle (in centimetres)");
                            i = double.Parse(Console.ReadLine());

                            // if statement needed to capture creating a circle with negative or below radius

                            if (i <= 0)
                            {
                                Console.WriteLine("A circle cannot have a negative radius, please select again");
                            }

                            else
                            {
                                Console.WriteLine($"Answer: {circle.CircleArea(i)} centimetres squared");
                            }
                            break;

                        case "T":
                            Console.Clear();
                            Calculator triangle = new Calculator();
                            Console.WriteLine("Please enter the base (in centimetres)");
                            i = double.Parse(Console.ReadLine());
                            Console.WriteLine("Please enter the height (in centimetres)");
                            j = double.Parse(Console.ReadLine());

                            // if statement needed to capture creating a triangle with negative or below base of height

                            if (i <= 0 || j <= 0)
                            {
                                Console.WriteLine("A triangle cannot have a negative base or height, please select again");
                            }

                            else
                            {
                                Console.WriteLine($"Answer: {triangle.TriangleArea(i, j)} centimetres squared");
                            }
                            break;

                        case "R":
                            Console.Clear();
                            Calculator remainder = new Calculator();
                            Console.WriteLine("Please enter your first number");
                            i = double.Parse(Console.ReadLine());
                            Console.WriteLine("Please enter your second number");
                            j = double.Parse(Console.ReadLine());
                            Console.WriteLine($"Answer: {remainder.Remainder(i, j)}");

                            break;

                        case "Q":
                            keepGoing = false;
                            break;

                        default:
                            Console.WriteLine("That is not a valid choice, please enter a valid choice");
                            break;
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        }
    }
}
