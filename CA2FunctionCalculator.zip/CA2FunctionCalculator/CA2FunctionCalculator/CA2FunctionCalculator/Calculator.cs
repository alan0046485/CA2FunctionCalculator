﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FunctionCalculator
{
    public class Calculator
    {
        public double Add(double i, double j)
        {
            return i + j;
        }

        public double Subtract(double i, double j)
        {
            return i - j;
        }

        public double Multiplication(double i, double j)
        {
            return i * j;
        }

        public double Division(double i, double j)
        {
            return i / j;
        }

        public double Square(double i)
        {
            return i * i;
        }

        public double Cube(double i)
        {
            return i * i * i;
        }

        public double SquareRoot(double i)
        {
            return Math.Sqrt(i);
        }

        public double CircleArea(double r)
        {
            return Math.PI * (r * r);
            
        }

        public double TriangleArea(double b, double h)
        {
            return (b / 2) *  h;
        }

        public double Remainder(double i, double j)
        {
            return i % j;
        }

    }
}
