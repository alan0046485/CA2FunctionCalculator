﻿using System;
using FunctionCalculator;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalcTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Add()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 4;
            double j = 6;
            double predicted = 10;
            double result = sum.Add(i, j);
            Assert.AreEqual(predicted, sum);

            // To check for negative numbers

            Calculator sum1 = new Calculator();

            double x = -4;
            double y = -6;
            double predicted1 = -10;
            double result1 = sum1.Add(x, y);
            Assert.AreEqual(predicted1, sum1);

            // To check for a sum including 0

            Calculator sum2 = new Calculator();

            double a = 0;
            double b = 1;
            double predicted2 = 1;
            double result2 = sum2.Add(a, b);
            Assert.AreEqual(predicted2, sum2);

        }
        [TestMethod]

        public void Subtract()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 4;
            double j = -6;
            double predicted = -2;
            double result = sum.Subtract(i, j);
            Assert.AreEqual(predicted, sum);

            // To check for two negative numbers

            Calculator sum1 = new Calculator();

            double x = -4;
            double y = -6;
            double predicted1 = 2;
            double result1 = sum1.Subtract(x, y);
            Assert.AreEqual(predicted1, sum1);

            // To check for a sum including 0

            Calculator sum2 = new Calculator();
            double a = 0;
            double b = -1;
            double predicted2 = -1;
            double result2 = sum2.Subtract(a, b);
            Assert.AreEqual(predicted2, sum2);
        }

        [TestMethod]

        public void Multiplication()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 4;
            double j = 6;
            double predicted = 24;
            double result = sum.Multiplication(i, j);
            Assert.AreEqual(predicted, sum);

            // To check for two negative numbers

            Calculator sum1 = new Calculator();

            double x = -4;
            double y = -6;
            double predicted1 = 24;
            double result1 = sum1.Multiplication(x, y);
            Assert.AreEqual(predicted1, sum1);

            // To check for a sum including 0

            Calculator sum2 = new Calculator();
            double a = 0;
            double b = -1;
            double predicted2 = 0;
            double result2 = sum2.Multiplication(a, b);
            Assert.AreEqual(predicted2, sum2);

        }

        public void Division()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 10;
            double j = 2;
            double predicted = 5;
            double result = sum.Division(i, j);
            Assert.AreEqual(predicted, sum);

            // To check for two negative numbers

            Calculator sum1 = new Calculator();

            double x = -9;
            double y = -3;
            double predicted1 = 3;
            double result1 = sum1.Division(x, y);
            Assert.AreEqual(predicted1, sum1);

            // To check for dividing 0

            Calculator sum2 = new Calculator();
            double a = 0;
            double b = 9;
            double predicted2 = 0;
            double result2 = sum2.Division(a, b);
            Assert.AreEqual(predicted2, sum2);

         }

        public void Square()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 10;
            double predicted = 100;
            double result = sum.Square(i);
            Assert.AreEqual(predicted, sum);

            // To check for a negative numbers

            Calculator sum1 = new Calculator();

            double x = -9;
            double predicted1 = 81;
            double result1 = sum1.Square(x);
            Assert.AreEqual(predicted1, sum1);

            // To check for 0

            Calculator sum2 = new Calculator();
            double a = 0;
            double predicted2 = 0;
            double result2 = sum2.Square(a);
            Assert.AreEqual(predicted2, sum2);

        }

        public void Cube()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 10;
            double predicted = 1000;
            double result = sum.Cube(i);
            Assert.AreEqual(predicted, sum);

            // To check for a negative number

            Calculator sum1 = new Calculator();

            double x = -2;
            double predicted1 = -8;
            double result1 = sum1.Cube(x);
            Assert.AreEqual(predicted1, sum1);

            // To check for 0

            Calculator sum2 = new Calculator();
            double a = 0;
            double predicted2 = 0;
            double result2 = sum2.Cube(a);
            Assert.AreEqual(predicted2, sum2);

        }

        public void SquareRoot()
        {
            // To check for a positive number

            Calculator sum = new Calculator();

            double i = 100;
            double predicted = 10;
            double result = sum.SquareRoot(i);
            Assert.AreEqual(predicted, sum);

            // You can't have a square root of a negative number

            // To check for 0

            Calculator sum2 = new Calculator();
            double a = 0;
            double predicted2 = 0;
            double result2 = sum2.SquareRoot(a);
            Assert.AreEqual(predicted2, sum2);

        }

        public void CircleArea()
        {
            // To check for a positive number

            Calculator sum = new Calculator();

            double i = 5;
            double predicted = 78.53981634;
            double result = sum.CircleArea(i);
            Assert.AreEqual(predicted, sum);

            // You can't have a cirle with a radius of 0 or less than 0 or it wouldn't exist

        }

        public void TriangleArea()
        {
            // To check for a positive number

            Calculator sum = new Calculator();

            double i = 10;
            double j = 5;
            double predicted = 25;
            double result = sum.TriangleArea(i, j);
            Assert.AreEqual(predicted, sum);

            // You can't have a triangle with a radius of 0 or less than 0 or it wouldn't exist

        }

        public void Remainder()
        {
            // To check for positive numbers

            Calculator sum = new Calculator();

            double i = 10;
            double j = 5;
            double predicted = 0;
            double result = sum.Remainder(i, j);
            Assert.AreEqual(predicted, sum);

            // To check for two negative numbers

            Calculator sum1 = new Calculator();

            double x = -10;
            double y = -5;
            double predicted1 = 0;
            double result1 = sum1.Remainder(x, y);
            Assert.AreEqual(predicted1, sum1);

            // To check for a positive and a negative number

            Calculator sum2 = new Calculator();

            double a = -10;
            double b = -5;
            double predicted2 = 0;
            double result2 = sum2.Remainder(a, b);
            Assert.AreEqual(predicted2, sum2);


        }


    }
}
